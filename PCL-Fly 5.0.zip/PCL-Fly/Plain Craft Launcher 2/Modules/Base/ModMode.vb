﻿Imports System.Runtime.CompilerServices

''' <summary>
''' 客户端模式层（UID）：0 = 正常版，1 = 调试版，默认 0。
''' 非法值一律回落为 0，避免读到脏配置后行为不可控。
''' </summary>
Public Module ModMode

#Region "常量"

    ''' <summary>正常版 UID。</summary>
    Public Const UIDNormal As Integer = 0

    ''' <summary>调试版 UID。</summary>
    Public Const UIDDebug As Integer = 1

    ''' <summary>默认 UID（正常版）。</summary>
    Public Const UIDDefault As Integer = UIDNormal

#End Region

#Region "模式"

    ''' <summary>运行模式。</summary>
    Public Enum RunModes As Integer
        NormalVersion = UIDNormal
        DebugVersion = UIDDebug
    End Enum

    ''' <summary>原始 UID（未做范围校验，可能是脏数据）。</summary>
    Public ReadOnly Property RawUID As Integer
        Get
            Return Settings.Get(Of Integer)("SystemUID")
        End Get
    End Property

    ''' <summary>UID 是否在允许范围内（只允许 0 或 1）。</summary>
    Public ReadOnly Property IsUIDValid As Boolean
        Get
            Dim R As Integer = RawUID
            Return R = UIDNormal OrElse R = UIDDebug
        End Get
    End Property

    ''' <summary>
    ''' 当前 UID，对外只可能返回 0 或 1；配置里是脏值时按默认 0 运行。
    ''' </summary>
    Public ReadOnly Property UID As Integer
        Get
            Dim R As Integer = RawUID
            If R <> UIDNormal AndAlso R <> UIDDebug Then Return UIDDefault
            Return R
        End Get
    End Property

    ''' <summary>当前运行模式。</summary>
    Public ReadOnly Property RunMode As RunModes
        Get
            Return If(UID = UIDDebug, RunModes.DebugVersion, RunModes.NormalVersion)
        End Get
    End Property

    ''' <summary>是否为调试版。</summary>
    Public ReadOnly Property IsDebugVersion As Boolean
        Get
            Return UID = UIDDebug
        End Get
    End Property

    ''' <summary>版本名后追加的模式后缀，正常版为空。</summary>
    Public ReadOnly Property ModeSuffix As String
        Get
            Return If(IsDebugVersion, " 调试版", "")
        End Get
    End Property

    ''' <summary>带模式标识的版本显示名；UID 不在 0/1 范围内时显示「滚」。</summary>
    Public ReadOnly Property VersionDisplayWithMode As String
        Get
            If Not IsUIDValid Then Return "滚"
            Return ModBase.VersionDisplay & ModeSuffix
        End Get
    End Property

    ''' <summary>
    ''' UID 不在允许范围（0/1）时直接显示「滚」。
    ''' 界面可在标题、版本信息处调用本方法展示。
    ''' </summary>
    Public Sub ShowRoll()
        Logger.Warn("UID 不在允许范围（0/1）内，显示「滚」")
        Try
            MyMsgBox("滚", "UID 不合法", "我知道了", IsWarn:=True, ForceWait:=True)
        Catch ex As Exception
            '启动早期窗体可能还没就绪，退化到系统对话框兜底
            Try
                MsgBox("滚", MsgBoxStyle.Critical, "UID 不合法")
            Catch
                Logger.Warn(ex, "显示 UID 非法提示失败")
            End Try
        End Try
    End Sub

    ''' <summary>启动自检：UID 不合法就显示「滚」，随后按正常版继续运行。</summary>
    Public Sub CheckUIDRange()
        If IsUIDValid Then Return
        ShowRoll()
    End Sub

    ''' <summary>
    ''' 切换 UID：只接受 0（正常版）与 1（调试版）。
    ''' 其它值不写入配置，直接显示「滚」。
    ''' </summary>
    Public Sub SetUID(Value As Integer)
        If Value <> UIDNormal AndAlso Value <> UIDDebug Then
            ShowRoll()
            Return
        End If
        If Value <> RawUID Then Settings.Set("SystemUID", Value)
        Logger.Info($"客户端模式已切换：UID={Value}（{If(Value = UIDDebug, "调试版", "正常版")}）")
    End Sub

    ''' <summary>启动时调用，在日志中记录当前模式。</summary>
    Public Sub InitMode()
        Logger.Info($"客户端模式：UID={UID}（{If(IsDebugVersion, "调试版", "正常版")}）")
    End Sub

    ''' <summary>
    ''' 解析启动参数里的 UID，支持 uid=1、--uid=1、/uid=1（大小写不敏感、顺序任意）。
    ''' 返回 Nothing 表示命令行没有指定，此时由设置里的值决定。
    ''' </summary>
    Public Function ParseUIDArgs(Args As String()) As Integer?
        If Args Is Nothing Then Return Nothing
        For Each Raw As String In Args
            Dim A As String = Raw.Trim().TrimStart("-"c, "/"c)
            If A.StartsWith("uid=", StringComparison.OrdinalIgnoreCase) Then
                Dim V As String = A.Substring(4).Trim()
                Select Case V
                    Case "0"
                        Return UIDNormal
                    Case "1"
                        Return UIDDebug
                    Case Else
                        Logger.Warn($"启动参数 uid={V} 不在允许范围（0/1）内")
                        ShowRoll()
                        Return Nothing
                End Select
            End If
        Next
        Return Nothing
    End Function

    ''' <summary>
    ''' 应用启动参数中的 UID：有参数就按参数切模式，没有就只记录当前模式；
    ''' 最后统一做一次范围自检，不合法则显示「滚」。
    ''' </summary>
    Public Sub ApplyUIDArgs(Args As String())
        Dim V As Integer? = ParseUIDArgs(Args)
        If V.HasValue Then
            Logger.Info($"启动参数指定 UID={V.Value}")
            SetUID(V.Value)
        Else
            InitMode()
        End If
        CheckUIDRange()
    End Sub

#End Region

End Module
