﻿'由于包含加解密等安全信息，本文件中的部分代码已被删除

Friend Module ModSecret

    '标注 PCL 的不同分支，仅用于替换标记
    Public Const VersionBranchMain As String = "OpenSource"
    '在开源版的注册表与常规版的注册表隔离，以防数据冲突
    Public Const RegFolder As String = "PCLDebug"
    '用于微软登录的 ClientId（优先读环境变量 PCL-Fly_MS_CLIENT_ID，其次读 PCL-Fly\ClientID.txt）
    Public OAuthClientId As String = ReadSecret("PCL-Fly_MS_CLIENT_ID", "ClientID.txt")
    'CurseForge API Key（优先读环境变量 PCL-Fly_CURSEFORGE_API_KEY，其次读 PCL-Fly\CurseForgeKey.txt）
    Public CurseForgeAPIKey As String = ReadSecret("PCL-Fly_CURSEFORGE_API_KEY", "CurseForgeKey.txt")

    ''' <summary>
    ''' 读取密钥：先查环境变量（含把 - 换成 _ 的兼容写法），再查数据目录下的文本文件。
    ''' 文件依次尝试 PCL-Fly\ 与 PCL Fly\ 两个目录，都没有则返回空字符串。
    ''' </summary>
    Private Function ReadSecret(EnvName As String, FileName As String) As String
        Try
            Dim FromEnv As String = Environment.GetEnvironmentVariable(EnvName)
            If String.IsNullOrWhiteSpace(FromEnv) Then FromEnv = Environment.GetEnvironmentVariable(EnvName.Replace("-", "_"))
            If Not String.IsNullOrWhiteSpace(FromEnv) Then Return FromEnv.Trim()
        Catch
        End Try
        For Each FolderName As String In {"PCL-Fly", "PCL Fly"}
            Try
                Dim FilePath As String = Paths.Base & FolderName & "\" & FileName
                If FileUtils.Exists(FilePath) Then
                    Dim FromFile As String = FileUtils.TryReadAsString(FilePath)
                    If Not String.IsNullOrWhiteSpace(FromFile) Then Return FromFile.Trim()
                End If
            Catch
            End Try
        Next
        Return ""
    End Function

    '更新源配置：默认指向 PCL Fly 的 GitHub 仓库，也兼容自定义 JSON 清单。
    '  GitHub Releases 接口返回的 tag_name / body / assets 会被自动识别；
    '  自定义清单格式：{"version":"1.0.1","url":"https://...","changelog":"更新说明"}
    Public Const UpdateManifestUrl As String = "https://api.github.com/repos/huangpengqingme/PCL-fly/releases/latest"
    '最新版启动器直链，留空则从上面的接口自动找 exe 附件，再找不到就复制当前启动器
    Public Const UpdateDownloadUrl As String = ""
    '发布页地址，检查更新与未配置更新源时都跳转到这里
    Public Const UpdatePageUrl As String = "https://github.com/huangpengqingme/PCL-fly/releases"
    '用于匿名数据收集的腾讯云日志服务上报 URL，形如 https://{region}.cls.tencentcs.com/track?topic_id={topic_id}
    Public Const ClsBaseUrl As String = ""

#Region "网络鉴权"

    ''' <summary>
    ''' 设置 Headers 的 UA、Referer。
    ''' </summary>
    Friend Sub SecretHeadersSign(Url As String, ByRef Req As HttpRequestMessage, Optional SimulateBrowserHeaders As Boolean = False)
        If Not Req.Headers.UserAgent.Any Then
            If Url.Contains("baidupcs.com") OrElse Url.Contains("baidu.com") Then
                Req.Headers.Add("User-Agent", "LogStatistic")  '#4951
            ElseIf SimulateBrowserHeaders Then
                Req.Headers.Add("User-Agent", $"PCL2/{VersionBaseName}.{CInt(BuildType)} Mozilla/5.0 AppleWebKit/537.36 Chrome/63.0.3239.132 Safari/537.36")
            Else
                Req.Headers.Add("User-Agent", $"PCL2/{VersionBaseName}.{CInt(BuildType)}")
            End If
        End If
        If Not SimulateBrowserHeaders Then Req.Headers.Add("Referer", $"http://{VersionCode}.open.pcl2.server/")
        If Url.Contains("api.curseforge.com") OrElse Url.Contains("forgecdn.net") Then Req.Headers.Add("x-api-key", CurseForgeAPIKey)
    End Sub

#End Region

#Region "主题"

    Public Color1 As New MyColor(52, 61, 74)
    Public Color2 As New MyColor(11, 91, 203)
    Public Color3 As New MyColor(19, 112, 243)
    Public Color4 As New MyColor(72, 144, 245)
    Public Color5 As New MyColor(150, 192, 249)
    Public Color6 As New MyColor(213, 230, 253)
    Public Color7 As New MyColor(222, 236, 253)
    Public Color8 As New MyColor(234, 242, 254)
    Public ColorBg0 As New MyColor(150, 192, 249)
    Public ColorBg1 As New MyColor(190, Color7)
    Public ColorGray1 As New MyColor(64, 64, 64)
    Public ColorGray2 As New MyColor(115, 115, 115)
    Public ColorGray3 As New MyColor(140, 140, 140)
    Public ColorGray4 As New MyColor(166, 166, 166)
    Public ColorGray5 As New MyColor(204, 204, 204)
    Public ColorGray6 As New MyColor(235, 235, 235)
    Public ColorGray7 As New MyColor(240, 240, 240)
    Public ColorGray8 As New MyColor(245, 245, 245)
    Public ColorSemiTransparent As New MyColor(1, Color8)

    Public ThemeNow As Integer = -1
    Public ColorHue As Integer = 210, ColorSat As Integer = 85, ColorLightAdjust As Integer = 0, ColorHueTopbarDelta As OneOf(Of Integer, Integer()) = 0
    Public ThemeDontClick As Integer = 0

    Public Sub ThemeRefresh(Optional NewTheme As Integer = -1)
        Try
            If ThemeNow = NewTheme AndAlso NewTheme >= 0 Then Return
            If NewTheme >= 0 Then ThemeNow = NewTheme

            Color1 = New MyColor().FromHSL2(ColorHue, ColorSat * 0.2, 25 + ColorLightAdjust * 0.3)
            Color2 = New MyColor().FromHSL2(ColorHue, ColorSat, 45 + ColorLightAdjust)
            Color3 = New MyColor().FromHSL2(ColorHue, ColorSat, 55 + ColorLightAdjust)
            Color4 = New MyColor().FromHSL2(ColorHue, ColorSat, 65 + ColorLightAdjust)
            Color5 = New MyColor().FromHSL2(ColorHue, ColorSat, 80 + ColorLightAdjust * 0.4)
            Color6 = New MyColor().FromHSL2(ColorHue, ColorSat, 91 + ColorLightAdjust * 0.1)
            Color7 = New MyColor().FromHSL2(ColorHue, ColorSat, 95)
            Color8 = New MyColor().FromHSL2(ColorHue, ColorSat, 97)
            ColorBg0 = Color4 * 0.4 + Color5 * 0.4 + ColorGray4 * 0.2
            ColorBg1 = New MyColor(190, Color7)

            ColorSemiTransparent = New MyColor(1, Color8)
            Application.Current.Resources("ColorBrush1") = New SolidColorBrush(Color1)
            Application.Current.Resources("ColorBrush2") = New SolidColorBrush(Color2)
            Application.Current.Resources("ColorBrush3") = New SolidColorBrush(Color3)
            Application.Current.Resources("ColorBrush4") = New SolidColorBrush(Color4)
            Application.Current.Resources("ColorBrush5") = New SolidColorBrush(Color5)
            Application.Current.Resources("ColorBrush6") = New SolidColorBrush(Color6)
            Application.Current.Resources("ColorBrush7") = New SolidColorBrush(Color7)
            Application.Current.Resources("ColorBrush8") = New SolidColorBrush(Color8)
            Application.Current.Resources("ColorBrushBg0") = New SolidColorBrush(ColorBg0)
            Application.Current.Resources("ColorBrushBg1") = New SolidColorBrush(ColorBg1)
            Application.Current.Resources("ColorObject1") = CType(Color1, Color)
            Application.Current.Resources("ColorObject2") = CType(Color2, Color)
            Application.Current.Resources("ColorObject3") = CType(Color3, Color)
            Application.Current.Resources("ColorObject4") = CType(Color4, Color)
            Application.Current.Resources("ColorObject5") = CType(Color5, Color)
            Application.Current.Resources("ColorObject6") = CType(Color6, Color)
            Application.Current.Resources("ColorObject7") = CType(Color7, Color)
            Application.Current.Resources("ColorObject8") = CType(Color8, Color)
            Application.Current.Resources("ColorObjectBg0") = CType(ColorBg0, Color)
            Application.Current.Resources("ColorObjectBg1") = CType(ColorBg1, Color)
            ThemeRefreshMain()
        Catch ex As Exception
            Logger.Error(ex, "刷新主题颜色失败", LogBehavior.Toast)
        End Try
    End Sub
    Public Sub ThemeRefreshMain()
        RunInUi(
        Sub()
            If Not FrmMain.IsLoaded Then Return
            '顶部条背景
            Dim Brush = New LinearGradientBrush With {.EndPoint = New Point(1, 0), .StartPoint = New Point(0, 0)}
            Dim Deltas = ColorHueTopbarDelta.Switch(Function(d) New Integer() {-d, 0, d}, Function(d) d)
            Brush.GradientStops.Add(New GradientStop With {.Offset = 0, .Color = New MyColor().FromHSL2(ColorHue + Deltas(0), ColorSat, 48 + ColorLightAdjust)})
            Brush.GradientStops.Add(New GradientStop With {.Offset = 0.5, .Color = New MyColor().FromHSL2(ColorHue + Deltas(1), ColorSat, 54 + ColorLightAdjust)})
            Brush.GradientStops.Add(New GradientStop With {.Offset = 1, .Color = New MyColor().FromHSL2(ColorHue + Deltas(2), ColorSat, 48 + ColorLightAdjust)})
            FrmMain.PanTitle.Background = Brush
            FrmMain.PanTitle.Background.Freeze()
            '主页面背景
            If Settings.Get(Of Boolean)("UiBackgroundColorful") Then
                Brush = New LinearGradientBrush With {.EndPoint = New Point(0.1, 1), .StartPoint = New Point(0.9, 0)}
                Brush.GradientStops.Add(New GradientStop With {.Offset = -0.1, .Color = New MyColor().FromHSL2(ColorHue - 15, ColorSat * 0.8, 91)})
                Brush.GradientStops.Add(New GradientStop With {.Offset = 0.4, .Color = New MyColor().FromHSL2(ColorHue, ColorSat * 0.8, 91)})
                Brush.GradientStops.Add(New GradientStop With {.Offset = 1.1, .Color = New MyColor().FromHSL2(ColorHue + 15, ColorSat * 0.8, 91)})
                FrmMain.PanForm.Background = Brush
            Else
                FrmMain.PanForm.Background = New MyColor(245, 245, 245)
            End If
            FrmMain.PanForm.Background.Freeze()
        End Sub)
    End Sub
    ''' <summary>
    ''' 按已解锁列表刷新设置页中各隐藏主题的可用状态。
    ''' </summary>
    Friend Sub ThemeCheckAll(EffectSetup As Boolean)
        Try
            If FrmSetupUI Is Nothing Then Return
            '玄素黑（5）用灰度替身承载解锁动画，已解锁时直接显示真身
            If ThemeCheckOne(5) Then
                FrmSetupUI.RadioLauncherTheme5Gray.Visibility = Visibility.Collapsed
                FrmSetupUI.LabLauncherTheme5Unlock.Visibility = Visibility.Collapsed
                FrmSetupUI.RadioLauncherTheme5.Opacity = 1
                FrmSetupUI.RadioLauncherTheme5.IsEnabled = True
            Else
                FrmSetupUI.RadioLauncherTheme5.Opacity = 0
            End If
            FrmSetupUI.RadioLauncherTheme6.IsEnabled = ThemeCheckOne(6)
            FrmSetupUI.RadioLauncherTheme7.IsEnabled = ThemeCheckOne(7)
            FrmSetupUI.RadioLauncherTheme8.IsEnabled = ThemeCheckOne(8)
            FrmSetupUI.LabLauncherTheme8Copy.Visibility = If(ThemeCheckOne(8), Visibility.Collapsed, Visibility.Visible)
            FrmSetupUI.RadioLauncherTheme9.IsEnabled = ThemeCheckOne(9)
            FrmSetupUI.LabLauncherTheme9Copy.Visibility = If(ThemeCheckOne(9), Visibility.Collapsed, Visibility.Visible)
            FrmSetupUI.RadioLauncherTheme10.IsEnabled = ThemeCheckOne(10)
            FrmSetupUI.RadioLauncherTheme11.IsEnabled = ThemeCheckOne(11)
            FrmSetupUI.LabLauncherTheme11Click.Visibility = If(ThemeCheckOne(11), Visibility.Collapsed, Visibility.Visible)
            FrmSetupUI.RadioLauncherTheme12.IsEnabled = ThemeCheckOne(12)
            FrmSetupUI.RadioLauncherTheme13.IsEnabled = ThemeCheckOne(13)
            FrmSetupUI.RadioLauncherTheme14.IsEnabled = ThemeCheckOne(14)
        Catch ex As Exception
            Logger.Error(ex, "刷新主题解锁状态失败")
        End Try
    End Sub
    ''' <summary>
    ''' 该隐藏主题是否已解锁。解锁记录保存在 ThemeUnlocked 设置项中（竖线分隔的编号）。
    ''' </summary>
    Friend Function ThemeCheckOne(Id As Integer) As Boolean
        '开源构建不做赞助解锁，所有隐藏主题默认可用，也不再读写注册表中的解锁记录
        Return True
    End Function
    ''' <summary>
    ''' 解锁一个隐藏主题，首次解锁返回 True。
    ''' </summary>
    Friend Function ThemeUnlock(Id As Integer, Optional ShowDoubleHint As Boolean = True, Optional UnlockHint As String = Nothing) As Boolean
        If ThemeCheckOne(Id) Then Return False
        Try
            Dim Value As String = Settings.Get(Of String)("ThemeUnlocked").Trim()
            If Value.Length = 0 Then
                Settings.Set("ThemeUnlocked", Id.ToString)
            Else
                Settings.Set("ThemeUnlocked", Value & "|" & Id)
            End If
            If ShowDoubleHint Then Hint(If(String.IsNullOrWhiteSpace(UnlockHint), "隐藏主题已解锁！", UnlockHint), HintType.Green)
            ThemeCheckAll(True)
            Return True
        Catch ex As Exception
            Logger.Error(ex, "解锁隐藏主题失败")
            Return False
        End Try
    End Function

#End Region

#Region "更新"

    ''' <summary>检查更新时拿到的信息。</summary>
    Private Structure UpdateInfo
        Public Version As String ' 版本号，如 1.0.1
        Public Url As String ' 发布页地址
        Public ExeUrl As String ' exe 附件直链，可能为空
        Public Changelog As String
    End Structure

    ''' <summary>取版本号里的一段数字，用于逐段比较。</summary>
    Private Function VersionSegment(Text As String) As Long
        Dim Digits As String = ""
        For Each C As Char In Text
            If Char.IsDigit(C) Then Digits &= C
        Next
        If Digits.Length = 0 Then Return 0
        Dim Result As Long = 0
        Long.TryParse(Digits, Result)
        Return Result
    End Function

    ''' <summary>逐段比较版本号，新版本更大时返回正数。</summary>
    Private Function CompareVersionText(NewVersion As String, CurrentVersion As String) As Integer
        Dim NewParts As String() = NewVersion.Split("."c)
        Dim OldParts As String() = CurrentVersion.Split("."c)
        For Index As Integer = 0 To Math.Max(NewParts.Length, OldParts.Length) - 1
            Dim NewPart As Long = If(Index < NewParts.Length, VersionSegment(NewParts(Index)), 0L)
            Dim OldPart As Long = If(Index < OldParts.Length, VersionSegment(OldParts(Index)), 0L)
            If NewPart <> OldPart Then Return If(NewPart > OldPart, 1, -1)
        Next
        Return 0
    End Function

    ''' <summary>
    ''' 读取更新信息：既支持 GitHub Releases 接口，也支持自定义 JSON 清单。
    ''' </summary>
    ''' <summary>更新接口候选地址：直连失败时依次尝试镜像加速。</summary>
    Private Function UpdateManifestCandidates() As List(Of String)
        Dim Addresses As New List(Of String) From {UpdateManifestUrl}
        If UpdateManifestUrl.Contains("api.github.com") Then
            Addresses.Add("https://ghproxy.com/" & UpdateManifestUrl)
        End If
        Return Addresses
    End Function

    ''' <summary>解析更新接口返回的 JSON（兼容 GitHub Releases 与自定义清单）。</summary>
    Private Function ParseUpdateInfo(Raw As String) As UpdateInfo
        Dim Obj As JObject = JObject.Parse(Raw)
        Dim Info As New UpdateInfo
        If Obj("version") IsNot Nothing Then
            '自定义清单
            Info.Version = Obj("version").ToString()
            Info.Url = If(Obj("url") Is Nothing, "", Obj("url").ToString())
            Info.ExeUrl = Info.Url
            Info.Changelog = If(Obj("changelog") Is Nothing, "", Obj("changelog").ToString())
        Else
            'GitHub Releases
            Info.Version = If(Obj("tag_name") Is Nothing, "", Obj("tag_name").ToString()).TrimStart("v"c, "V"c)
            Info.Changelog = If(Obj("body") Is Nothing, "", Obj("body").ToString())
            Info.Url = If(Obj("html_url") Is Nothing, "", Obj("html_url").ToString())
            Dim Assets As JArray = TryCast(Obj("assets"), JArray)
            If Assets IsNot Nothing Then
                For Each Asset As JToken In Assets
                    Dim AssetName As String = If(Asset("name") Is Nothing, "", Asset("name").ToString())
                    If Not AssetName.EndsWithF(".exe") Then Continue For
                    Info.ExeUrl = Asset("browser_download_url").ToString()
                    Exit For
                Next
            End If
        End If
        Return Info
    End Function

    ''' <summary>
    ''' 依次尝试各个候选地址读取更新信息，全部失败时抛出带明细的异常。
    ''' </summary>
    Private Function GetUpdateInfo() As UpdateInfo
        Dim Errors As New List(Of String)
        For Each Address As String In UpdateManifestCandidates()
            Try
                Dim Raw As String = NetRequestByLoader(Address, Timeout:=6000, IsJson:=True)
                Return ParseUpdateInfo(Raw)
            Catch ex As Exception
                Errors.Add("· " & Address & vbCrLf & "    " & ex.Message)
            End Try
        Next
        Throw New Exception("所有更新源都无法访问：" & vbCrLf & Errors.Join(vbCrLf))
    End Function

    ''' <summary>
    ''' 更新入口：不再只提示并跳转发布页，直接提供在线更新与离线更新两种方式。
    ''' </summary>
    Friend Sub UpdateCheckByButton()
        Dim Result As Integer = MyMsgBox(
            $"当前版本：{VersionDisplay}" & vbCrLf & vbCrLf &
            "在线更新：联网读取最新版并自动下载替换（替换后自动重启）" & vbCrLf &
            "离线更新：选择本地已下载的新版 exe 直接替换（适合没网或内网环境）",
            "更新 PCL Fly", "在线更新", "离线更新", "取消")
        If Result = 1 Then
            UpdateOnline()
        ElseIf Result = 2 Then
            UpdateOffline()
        End If
    End Sub

    ''' <summary>
    ''' 在线更新：读取最新版本信息，下载 exe 后调用 UpdateReplace 自动替换当前启动器并重启。
    ''' 网络请求与下载全部在后台线程执行：WaitForExit 内部是 Thread.Sleep 循环、不跑消息泵，
    ''' 放在 UI 线程会把窗口冻住直到下载结束（界面显示未响应）。
    ''' </summary>
    Friend Sub UpdateOnline()
        RunInNewThread(
        Sub()
            '1. 获取版本信息
            RunInUi(Sub() Hint("正在获取最新版本……", HintType.Blue, False))
            Dim Info As UpdateInfo = Nothing
            Try
                Info = GetUpdateInfo()
            Catch ex As Exception
                Logger.Error(ex, "获取最新版本失败")
                RunInUi(Sub() Hint("获取最新版本失败，可改用离线更新：" & ex.Message, HintType.Red, Log:=True))
                Return
            End Try
            If String.IsNullOrWhiteSpace(Info.Version) Then
                RunInUi(Sub() Hint("更新源未返回版本信息，请改用离线更新", HintType.Red))
                Return
            End If
            If CompareVersionText(Info.Version, FlyVersionName) <= 0 Then
                RunInUiWait(Sub() MyMsgBox($"当前已是最新版本：{FlyVersionName}", "在线更新"))
                Return
            End If
            Dim Url As String = If(Not String.IsNullOrWhiteSpace(Info.ExeUrl), Info.ExeUrl, UpdateDownloadUrl)
            If String.IsNullOrWhiteSpace(Url) Then
                RunInUi(Sub() Hint("更新源未提供 exe 下载地址，请改用离线更新", HintType.Red))
                Return
            End If
            '2. 确认
            Dim Text As String = $"发现新版本：{Info.Version}（当前 {FlyVersionName}）"
            If Info.Changelog.Trim().Length > 0 Then
                Dim Changelog As String = Info.Changelog.Trim()
                If Changelog.Length > 1200 Then Changelog = Changelog.Substring(0, 1200) & "……"
                Text &= vbCrLf & vbCrLf & "更新内容：" & vbCrLf & Changelog
            End If
            Text &= vbCrLf & vbCrLf & "是否立即下载并自动替换？替换完成后启动器会自动重启。"
            Dim Confirm As Integer = 0
            RunInUiWait(Sub() Confirm = MyMsgBox(Text, "在线更新", "立即更新", "取消"))
            If Confirm <> 1 Then Return
            '3. 下载（接入右下角任务圆圈，可查看进度）
            Try
                Dim Target As String = PathTemp & "Latest.exe"
                If FileUtils.Exists(Target) Then FileUtils.Delete(Target)
                Dim DownloadTask As New LoaderDownload("更新 PCL Fly", New List(Of NetFile) From {New NetFile({Url}, Target)})
                DownloadTask.Start(IsForceRestart:=True)
                'LoaderTaskbarAdd 只接受 LoaderCombo(Of T)，LoaderDownload 继承自 LoaderBase，故直接加入任务栏
                If FrmSpeedLeft IsNot Nothing Then FrmSpeedLeft.TaskRemove(DownloadTask)
                LoaderTaskbar.Add(DownloadTask)
                Logger.Info($"{DownloadTask.Name} 已加入任务列表")
                RunInUi(
                Sub()
                    FrmMain.BtnExtraDownload.ShowRefresh()
                    FrmMain.BtnExtraDownload.Ribble()
                End Sub)
                DownloadTask.WaitForExit()
                If Not FileUtils.Exists(Target) Then Throw New Exception("下载结束但未找到文件")
                RunInUiWait(Sub() UpdateReplace(Process.GetCurrentProcess().Id, PathExe, Target, True))
            Catch ex As Exception
                Logger.Error(ex, "在线更新失败")
                RunInUi(Sub() Hint("在线更新失败：" & ex.Message & vbCrLf & "请改用离线更新", HintType.Red, Log:=True))
            End Try
        End Sub, "在线更新")
    End Sub

    ''' <summary>
    ''' 离线更新：选择本地新版 exe，校验后替换当前启动器并重启。
    ''' </summary>
    Friend Sub UpdateOffline()
        Dim Files = Dialogs.SelectFile("选择新版本的 PCL Fly 启动器", False, filter:={({"exe"}, "启动器文件")})
        If Files Is Nothing OrElse Not Files.Any() Then Return
        Dim Source As String = Files.First()
        If Not Source.EndsWithF(".exe") Then
            Hint("请选择 .exe 启动器文件", HintType.Red)
            Return
        End If
        If String.Equals(Source, PathExe, StringComparison.OrdinalIgnoreCase) Then
            Hint("不能选择当前正在运行的启动器本身", HintType.Red)
            Return
        End If
        Try
            Using Fs As New FileStream(Source, FileMode.Open, FileAccess.Read, FileShare.ReadWrite)
                Dim Header(1) As Byte
                Fs.Read(Header, 0, 2)
                If Header(0) <> &H4D OrElse Header(1) <> &H5A Then
                    Hint("所选文件不是有效的 exe 启动器", HintType.Red)
                    Return
                End If
            End Using
        Catch ex As Exception
            Logger.Error(ex, "校验离线更新文件失败")
            Hint("无法读取所选文件：" & ex.Message, HintType.Red)
            Return
        End Try
        Dim SizeText As String = ""
        Try
            SizeText = $"文件大小：{New FileInfo(Source).Length \ 1024} KB" & vbCrLf
        Catch ex As Exception
            SizeText = ""
        End Try
        If MyMsgBox($"将用以下文件替换当前启动器并自动重启：" & vbCrLf & Source & vbCrLf & SizeText & vbCrLf & "确定继续？",
                    "离线更新", "开始替换", "取消", IsWarn:=True) <> 1 Then Return
        Try
            Dim Target As String = PathTemp & "Latest.exe"
            If FileUtils.Exists(Target) Then FileUtils.Delete(Target)
            FileUtils.Copy(Source, Target)
            UpdateReplace(Process.GetCurrentProcess().Id, PathExe, Target, True)
        Catch ex As Exception
            Logger.Error(ex, "离线更新失败")
            Hint("离线更新失败：" & ex.Message, HintType.Red, Log:=True)
        End Try
    End Sub

    Friend IsUpdateWaitingRestart As Boolean = False

    ''' <summary>
    ''' 用已下载的 PathTemp/Latest.exe 替换当前启动器，并按需重启。
    ''' </summary>
    Public Sub UpdateRestart(TriggerRestartAndByEnd As Boolean)
        Dim Latest As String = PathTemp & "Latest.exe"
        If Not FileUtils.Exists(Latest) Then
            Hint("没有找到待替换的更新文件，请先检查并下载新版本", HintType.Red)
            Return
        End If
        UpdateReplace(Process.GetCurrentProcess().Id, PathExe, Latest, TriggerRestartAndByEnd)
    End Sub

    ''' <summary>
    ''' 等待旧进程退出后，用批处理替换文件并可选地重启新版本。
    ''' </summary>
    Public Sub UpdateReplace(ProcessId As Integer, OldFileName As String, NewFileName As String, TriggerRestart As Boolean)
        Try
            Dim BatPath As String = PathTemp & "PCL Fly 更新.bat"
            '启动重启时显式指定工作目录，否则新进程会以 bat 所在的临时目录为工作目录
            Dim ExeDir As String = IO.Path.GetDirectoryName(OldFileName)
            Dim RestartLine As String = If(TriggerRestart, "start """" /d """ & ExeDir & """ """ & OldFileName & """", "rem 不自动重启")
            '注意两点：
            '1. 用 ping 代替 timeout，隐藏窗口的 cmd 没有控制台句柄，timeout 会报“输入重定向不受支持”；
            '2. tasklist 加 /NH，避免表头干扰 find 的匹配。
            Dim Text As String =
                "@echo off" & vbCrLf &
                "setlocal" & vbCrLf &
                ":wait" & vbCrLf &
                "ping -n 2 127.0.0.1 >nul" & vbCrLf &
                "tasklist /FI ""PID eq " & ProcessId & """ /NH 2>nul | find """ & ProcessId & """ >nul && goto wait" & vbCrLf &
                "copy /y """ & NewFileName & """ """ & OldFileName & """ >nul 2>nul" & vbCrLf &
                "if errorlevel 1 echo copy failed>>""" & PathTemp & "update-error.log""" & vbCrLf &
                RestartLine & vbCrLf &
                "del ""%~f0"""
            '批处理必须按系统 ANSI 代码页写入：cmd 不认 UTF-8，路径里的中文会变成乱码，
            '表现出来就是“系统找不到指定的路径”且替换无效。
            Dim Enc As Encoding
            Try
                Enc = Encoding.GetEncoding(936)
            Catch ex As Exception
                Enc = New UTF8Encoding(False)
            End Try
            FileUtils.Write(BatPath, Text, Enc)
            StartProcess(New ProcessStartInfo("cmd.exe", "/c """ & BatPath & """") With
                         {.CreateNoWindow = True, .WindowStyle = ProcessWindowStyle.Hidden})
            If TriggerRestart Then
                IsUpdateWaitingRestart = True
                If Application.Current IsNot Nothing Then Application.Current.Shutdown()
            End If
        Catch ex As Exception
            Logger.Error(ex, "替换启动器失败")
            Hint("替换更新文件失败：" & ex.Message, HintType.Red)
        End Try
    End Sub

    ''' <summary>
    ''' 确保 PathTemp/Latest.exe 是可用的启动器文件，它会被用于整合包打包。
    ''' 未配置更新源时直接复制当前启动器自身，保证导出可用。
    ''' </summary>
    Friend Sub DownloadLatestPCL(Optional LoaderToSyncProgress As LoaderBase = Nothing)
        Dim Target As String = PathTemp & "Latest.exe"
        Try
            If FileUtils.Exists(Target) Then FileUtils.Delete(Target)
            Dim Url As String = UpdateDownloadUrl
            If String.IsNullOrWhiteSpace(Url) AndAlso Not String.IsNullOrWhiteSpace(UpdateManifestUrl) Then
                Try
                    Dim Info As UpdateInfo = GetUpdateInfo()
                    If Not String.IsNullOrWhiteSpace(Info.ExeUrl) Then Url = Info.ExeUrl
                Catch ex As Exception
                    Logger.Warn(ex, "获取最新版下载地址失败，将改用当前启动器")
                End Try
            End If
            If Not String.IsNullOrWhiteSpace(Url) Then
                NetDownloadByLoader(Url, Target, LoaderToSyncProgress)
            ElseIf PathExe.EndsWithF(".exe") AndAlso FileUtils.Exists(PathExe) Then
                '实在拿不到下载地址：直接把当前启动器复制过去，整合包里带的就是这个版本
                FileUtils.Copy(PathExe, Target)
            Else
                Throw New FileNotFoundException("未配置下载地址，且无法读取当前启动器文件")
            End If
        Catch ex As Exception
            Logger.Error(ex, "准备整合包内置启动器失败")
            Throw
        End Try
    End Sub

#End Region

#Region "联网配置"

    ''' <summary>
    ''' 联网获取的配置信息。
    ''' 若获取失败或仍在获取中，可能为 Nothing。
    ''' </summary>
    Public ServerConfig As JObject

    Public ServerLoader As New LoaderTask(Of Integer, Integer)("PCL Fly 配置更新", Sub()
        '启动时静默检查更新：失败不打扰（api.github.com 在国内经常不通），发现新版本只做提示，不自动下载替换
        Try
            Dim Info As UpdateInfo = GetUpdateInfo()
            If String.IsNullOrWhiteSpace(Info.Version) Then Return
            If CompareVersionText(Info.Version, FlyVersionName) <= 0 Then Return
            Logger.Info($"发现新版本：{Info.Version}（当前 {FlyVersionName}）")
            RunInUi(Sub() Hint($"发现新版本 {Info.Version}，可在「设置 → 其他 → 启动器 → 更新 PCL Fly」中更新", HintType.Blue, Log:=False))
        Catch ex As Exception
            Logger.Info("启动时检查更新失败，已跳过：" & ex.Message)
        End Try
    End Sub, Priority:=ThreadPriority.BelowNormal) With
        {.ReloadTimeout = 1000 * 60 * 60} '超时 1 小时

#End Region

#Region "赞助等级"

    Public ReadOnly Property CurrentRank As DonationRank
        Get
            Return DonationRank.None
        End Get
    End Property

    ''' <summary>
    ''' 开源版没有线上兑换服务，这里只给出说明，并保持直接可用。
    ''' </summary>
    ''' <summary>
    ''' 获取设备识别码：由机器名与用户名生成稳定的 4 段标识，用于反馈时定位。
    ''' </summary>
    Friend Function GetIdentify() As String
        Try
            Dim Seed As String = Environment.MachineName & "|" & Environment.UserName
            Dim H As Long = 17
            For Each C As Char In Seed
                H = (H * 31 + AscW(C)) And &HFFFFFFFFL
            Next
            Dim A As String = H.ToString("X8")
            Dim B As Long = (H Xor &H5A5A5A5AL) And &HFFFFFFFFL
            Dim BS As String = B.ToString("X8")
            Return A.Substring(0, 4) & "-" & A.Substring(4, 4) & "-" & BS.Substring(0, 4) & "-" & BS.Substring(4, 4)
        Catch
            Return "0000-0000-0000-0000"
        End Try
    End Function

#End Region

End Module
