Imports System.Windows.Markup

<ContentProperty("SearchTags")>
Public Class PageResource

#Region "属性"

    ''' <summary>
    ''' 用于 XAML 快速设置的 Tag 下拉框列表。
    ''' </summary>
    Public ReadOnly Property SearchTags As ItemCollection
        Get
            Return ComboSearchTag.Items
        End Get
    End Property

    ''' <summary>
    ''' 英文前后不含空格的可读资源类型名，例如 "Mod"、"整合包"。
    ''' </summary>
    Public Property TypeName As String
        Get
            Return _TypeName
        End Get
        Set(Value As String)
            If _TypeName = Value Then Return
            _TypeName = Value
            Loader.Name = $"社区资源获取：{Value}"
        End Set
    End Property
    Private _TypeName As String = ""

    ''' <summary>
    ''' 英文前后含一个空格的可读资源类型名，例如 " Mod "、"整合包"。
    ''' </summary>
    Public Property TypeNameSpaced As String
        Get
            Return _TypeNameSpaced
        End Get
        Set(Value As String)
            If _TypeNameSpaced = Value Then Return
            _TypeNameSpaced = Value
            PanAlways.Title = $"搜索{Value}"
            Load.Text = $"正在获取{Value}列表"
        End Set
    End Property
    Private _TypeNameSpaced As String = ""

    ''' <summary>
    ''' 该页面对应的资源类型。
    ''' </summary>
    Public Property PageType As ResourceTypes
        Get
            Return _Type
        End Get
        Set(Value As ResourceTypes)
            If _Type = Value Then Return
            _Type = Value
            BtnSearchInstallModPack.Visibility = If(Value = ResourceTypes.ModPack, Visibility.Visible, Visibility.Collapsed)
        End Set
    End Property
    Private _Type As ResourceTypes = -1

#End Region

#Region "加载"

    ''' <summary>
    ''' 在切换到页面时，应自动将筛选项设置为与该目标 MC 版本和加载器相同。
    ''' </summary>
    Public Shared TargetInstance As McInstance = Nothing
    ''' <summary>
    ''' 在切换到该页面时自动设置的搜索框内的内容。
    ''' </summary>
    Public Shared TargetName As String = Nothing

    '在点击 MyResourceItem 时会获取 Loader 的输入，以使资源详情页面可以应用相同的筛选项
    Public Loader As LoaderTask(Of ResourceSearcher.SearchRequest, Integer) = ResourceSearcher.GetLoader(AddressOf LoaderInput)

    Private Sub PageResource_Loaded(sender As Object, e As EventArgs) Handles Me.Loaded
        Static IsFirstLoaded As Boolean = False
        Static SourceListInited As Boolean = False
        If Not SourceListInited Then
            SourceListInited = True
            RefreshSourceCombo()
        End If
        '不知道从 Initialized 改成 Loaded 会不会有问题，但用 Initialized 会导致初始的筛选器修改被覆盖回默认值
        If TargetInstance IsNot Nothing Then
            '设置目标
            ResetFilter() '重置筛选器
            TextSearchVersion.Text = TargetInstance.Version.VanillaName
            Dim GetTargetItemByName =
            Function(Name As String) As MyComboBoxItem
                For Each Item As MyComboBoxItem In ComboSearchLoader.Items
                    If Item.Content = Name Then Return Item
                Next
                Return ComboSearchLoader.Items(0)
            End Function
            If TargetInstance.Version.ModLoaders.HasFlagF(ModLoaders.Forge) Then
                ComboSearchLoader.SelectedItem = GetTargetItemByName("Forge")
            ElseIf TargetInstance.Version.ModLoaders.HasFlagF(ModLoaders.Fabric) Then
                ComboSearchLoader.SelectedItem = GetTargetItemByName("Fabric")
            ElseIf TargetInstance.Version.ModLoaders.HasFlagF(ModLoaders.NeoForge) Then
                ComboSearchLoader.SelectedItem = GetTargetItemByName("NeoForge")
            End If
            TargetInstance = Nothing
            If TargetName IsNot Nothing Then
                TextSearchName.Text = TargetName
                TargetName = Nothing
            End If
            '如果已经完成请求，则重新开始
            If IsFirstLoaded Then StartNewSearch()
            ScrollToHome()
        End If
        '加载器初始化
        If IsFirstLoaded Then Return
        IsFirstLoaded = True
        CType(Parent, MyPageRight).PageLoaderInit(Load, PanLoad, PanContent, PanAlways, Loader, AddressOf Load_OnFinish, AddressOf LoaderInput)
        '将最高 Drop 加入筛选
        If AllDrops IsNot Nothing AndAlso AllDrops.First > 250 Then
            Dim HighestVersion As String = McVersion.DropToVersion(AllDrops.First)
            If CType(TextSearchVersion.Items(1), MyComboBoxItem).Content.ToString <> HighestVersion Then '0 是全部
                TextSearchVersion.Items.Insert(1, New MyComboBoxItem With {.Content = HighestVersion})
            End If
        End If
    End Sub
    Private Function LoaderInput() As ResourceSearcher.SearchRequest
        Dim Request As New ResourceSearcher.SearchRequest(PageType, Storage, (Page + 1) * PAGE_SIZE)
        Dim GameVersion As String = If(TextSearchVersion.Text = "全部 (也可自行输入)", Nothing,
            If(TextSearchVersion.Text.Contains(".") OrElse TextSearchVersion.Text.Contains("w"), TextSearchVersion.Text, Nothing))
        With Request
            .SearchText = TextSearchName.Text
            .GameVersion = GameVersion
            .Tag = ComboSearchTag.SelectedItem.Tag
            .ModLoaders = If(PageType = ResourceTypes.Mod, Val(ComboSearchLoader.SelectedItem.Tag), ModLoaders.None)
            .Sources = CType(Val(ComboSearchSource.SelectedItem.Tag), ResourcePlatforms)
        End With
        Return Request
    End Function

#End Region

    Public Storage As New ResourceSearcher.SearchResult
    ''' <summary>
    ''' 每页展示的结果数量。
    ''' </summary>
    Public Const PAGE_SIZE = 40
    Public Page As Integer = 0

    '结果 UI 化
    Private Sub Load_OnFinish()
        Try
            Logger.Info($"开始可视化{TypeNameSpaced}列表，已储藏 {Storage.Results.Count} 个结果，当前在第 {Page + 1} 页")
            '列表项
            PanProjects.Children.Clear()
            Dim Index As Integer = Math.Min(Page * PAGE_SIZE, Storage.Results.Count - 1)
            For Each Result In Storage.Results.GetRange(Index, Math.Min(Storage.Results.Count - Index, PAGE_SIZE))
                PanProjects.Children.Add(Result.ToResourceItem(
                    ShowMcVersionDesc:=Loader.Input.GameVersion Is Nothing,
                    ShowLoaderDesc:=Loader.Input.ModLoaders = ModLoaders.None AndAlso (PageType = ResourceTypes.Mod OrElse PageType = ResourceTypes.ModPack)))
            Next
            '页码
            CardPages.Visibility = If(Storage.Results.Count > 40 OrElse
                                      Storage.CurseForgeOffset < Storage.CurseForgeTotal OrElse Storage.ModrinthOffset < Storage.ModrinthTotal,
                                      Visibility.Visible, Visibility.Collapsed)
            LabPage.Text = Page + 1
            BtnPageFirst.IsEnabled = Page > 1
            BtnPageFirst.Opacity = If(Page > 1, 1, 0.2)
            BtnPageLeft.IsEnabled = Page > 0
            BtnPageLeft.Opacity = If(Page > 0, 1, 0.2)
            Dim IsRightEnabled As Boolean = '由于 WPF 的未知 bug，读取到的 IsEnabled 可能是错误的值（#3319）
                Storage.Results.Count > PAGE_SIZE * (Page + 1) OrElse
                Storage.CurseForgeOffset < Storage.CurseForgeTotal OrElse Storage.ModrinthOffset < Storage.ModrinthTotal
            BtnPageRight.IsEnabled = IsRightEnabled
            BtnPageRight.Opacity = If(IsRightEnabled, 1, 0.2)
            '错误信息
            If Storage.ErrorMessage Is Nothing Then
                HintError.Visibility = Visibility.Collapsed
            Else
                HintError.Visibility = Visibility.Visible
                HintError.Text = Storage.ErrorMessage
            End If
            '强制返回顶部
            ScrollToTop()
        Catch ex As Exception
            Logger.Error(ex, $"可视化{TypeNameSpaced}列表出错")
        End Try
    End Sub

    '自动重试
    Private Sub Load_State(sender As Object, state As MyLoading.MyLoadingState, oldState As MyLoading.MyLoadingState) Handles Load.StateChanged
        Select Case Loader.State
            Case LoadState.Failed
                Dim ErrorMessage As String = ""
                If Loader.Error IsNot Nothing Then ErrorMessage = Loader.Error.Message
                If ErrorMessage.Contains("不是有效的 json 文件") Then
                    Logger.Warn($"下载的{TypeNameSpaced}列表 json 文件损坏，已自动重试")
                    CType(Parent, MyPageRight).PageLoaderRestart()
                End If
        End Select
    End Sub

    '切换页码
    Private Sub BtnPageFirst_Click(sender As Object, e As RoutedEventArgs) Handles BtnPageFirst.Click
        ChangePage(0)
    End Sub
    Private Sub BtnPageLeft_Click(sender As Object, e As RoutedEventArgs) Handles BtnPageLeft.Click
        ChangePage(Page - 1)
    End Sub
    Private Sub BtnPageRight_Click(sender As Object, e As RoutedEventArgs) Handles BtnPageRight.Click
        ChangePage(Page + 1)
    End Sub
    Private Sub ChangePage(NewPage As Integer)
        CardPages.IsEnabled = False
        Page = NewPage
        FrmMain.BackToTop()
        Logger.Info($"{TypeName}：切换到第 {Page + 1} 页")
        RunInThread(
        Sub()
            Thread.Sleep(100) '等待向上滚的动画结束
            RunInUi(Sub() CardPages.IsEnabled = True)
            Loader.Start()
        End Sub)
    End Sub

#Region "搜索"

    '搜索按钮
    Private Sub StartNewSearch() Handles BtnSearchRun.Click
        Dim SelectedSource As MyComboBoxItem = TryCast(ComboSearchSource.SelectedItem, MyComboBoxItem)
        If SelectedSource IsNot Nothing AndAlso SelectedSource.Tag IsNot Nothing AndAlso SelectedSource.Tag.ToString = "0" Then
            Hint("请先在「来源」里选择一个源，或先完成自定义源的添加", HintType.Red)
            Return
        End If
        Page = 0
        If Loader.ShouldStart(LoaderInput()) Then Storage = New ResourceSearcher.SearchResult '避免连续搜索两次导致 ProjectStorage 引用丢失（#1311）
        Loader.Start()
    End Sub
    Private Sub EnterTrigger(sender As Object, e As KeyEventArgs) Handles TextSearchName.KeyDown, TextSearchVersion.KeyDown
        If e.Key = Key.Enter Then StartNewSearch()
    End Sub

    '重置按钮
    Private Sub ResetFilter() Handles BtnSearchReset.Click
        TextSearchName.Text = ""
        TextSearchVersion.Text = "全部 (也可自行输入)"
        TextSearchVersion.SelectedIndex = 0
        ComboSearchSource.SelectedIndex = 0
        ComboSearchTag.SelectedIndex = 0
        ComboSearchLoader.SelectedIndex = 0
        Loader.LastFinishedTime = 0 '要求强制重新开始
    End Sub

    '版本选择
    '#3067：当下拉菜单展开时，程序会被 WPF 挂起，因而无法更新 Grid 布局，所以必须延迟到下拉菜单收起后才能更新
    Private Sub TextSearchVersion_TextChanged() Handles TextSearchVersion.TextChanged
        If Not TextSearchVersion.IsDropDownOpen Then UpdateSearchLoaderVisibility()
    End Sub
    Private Sub UpdateSearchLoaderVisibility() Handles TextSearchVersion.DropDownClosed
        If PageType = ResourceTypes.Mod AndAlso (TextSearchVersion.Text.Contains(".") OrElse TextSearchVersion.Text.Contains("w")) Then
            ComboSearchLoader.Visibility = Visibility.Visible
            Grid.SetColumnSpan(TextSearchVersion, 1)
        Else
            ComboSearchLoader.Visibility = Visibility.Collapsed
            Grid.SetColumnSpan(TextSearchVersion, 2)
            ComboSearchLoader.SelectedIndex = 0
        End If
    End Sub

#End Region

#Region "自定义源"

    ''' <summary>自定义源在下拉框中的名称后缀。</summary>
    Private Const CustomSourceSuffix As String = "（自定义）"
    ''' <summary>展开「添加自定义源」前记录的来源序号，取消时用于还原。</summary>
    Private LastSourceIndex As Integer = 0

    ''' <summary>
    ''' 重建来源下拉框：内置项 + 已保存的自定义源 + 添加入口。
    ''' </summary>
    Private Sub RefreshSourceCombo()
        Dim SelectedContent As String = "全部"
        Dim Selected As MyComboBoxItem = TryCast(ComboSearchSource.SelectedItem, MyComboBoxItem)
        If Selected IsNot Nothing AndAlso Selected.Content IsNot Nothing Then SelectedContent = Selected.Content.ToString
        AniControlEnabled += 1
        Try
            ComboSearchSource.Items.Clear()
            ComboSearchSource.Items.Add(New MyComboBoxItem With {.Content = "全部", .Tag = "3"})
            ComboSearchSource.Items.Add(New MyComboBoxItem With {.Content = "CurseForge", .Tag = "1"})
            ComboSearchSource.Items.Add(New MyComboBoxItem With {.Content = "Modrinth", .Tag = "2"})
            For Each Token As JToken In ReadCustomSources()
                Dim Source As JObject = CType(Token, JObject)
                ComboSearchSource.Items.Add(New MyComboBoxItem With {
                    .Content = Source("name").ToString & CustomSourceSuffix,
                    .Tag = If(Source("protocol").ToString = "1", "1", "2")})
            Next
            ComboSearchSource.Items.Add(New MyComboBoxItem With {.Content = "＋ 添加自定义源…", .Tag = "0"})
            '恢复原来的选择
            ComboSearchSource.SelectedIndex = 0
            For Each Item As MyComboBoxItem In ComboSearchSource.Items
                If Item.Content IsNot Nothing AndAlso Item.Content.ToString = SelectedContent Then
                    ComboSearchSource.SelectedItem = Item
                    Exit For
                End If
            Next
        Catch ex As Exception
            Logger.Error(ex, "刷新资源来源列表失败")
        Finally
            AniControlEnabled -= 1
        End Try
    End Sub

    ''' <summary>读取已保存的自定义源列表（JSON 数组）。</summary>
    Private Function ReadCustomSources() As JArray
        Dim Raw As String = Settings.Get(Of String)("CustomModSources")
        If String.IsNullOrWhiteSpace(Raw) Then Return New JArray
        Try
            Return JArray.Parse(Raw)
        Catch ex As Exception
            Logger.Warn(ex, "自定义源配置解析失败")
            Return New JArray
        End Try
    End Function

    ''' <summary>按当前选中的来源决定是否启用自定义镜像。</summary>
    Private Sub ApplyCustomSource()
        ModDownload.CustomModSourceBase = ""
        ModDownload.CustomModSourceProtocol = ResourcePlatforms.Any
        Dim Selected As MyComboBoxItem = TryCast(ComboSearchSource.SelectedItem, MyComboBoxItem)
        If Selected Is Nothing OrElse Selected.Content Is Nothing Then Return
        Dim Content As String = Selected.Content.ToString
        If Not Content.EndsWithF(CustomSourceSuffix) Then Return
        Dim SourceName As String = Content.Substring(0, Content.Length - CustomSourceSuffix.Length)
        For Each Token As JToken In ReadCustomSources()
            Dim Source As JObject = CType(Token, JObject)
            If Source("name").ToString <> SourceName Then Continue For
            ModDownload.CustomModSourceBase = Source("url").ToString
            ModDownload.CustomModSourceProtocol =
                If(Source("protocol").ToString = "1", ResourcePlatforms.CurseForge, ResourcePlatforms.Modrinth)
            Return
        Next
    End Sub

    Private Sub ComboSearchSource_SelectionChanged(sender As Object, e As SelectionChangedEventArgs) Handles ComboSearchSource.SelectionChanged
        If AniControlEnabled <> 0 Then Return
        Dim Selected As MyComboBoxItem = TryCast(ComboSearchSource.SelectedItem, MyComboBoxItem)
        Dim Tag As String = If(Selected IsNot Nothing AndAlso Selected.Tag IsNot Nothing, Selected.Tag.ToString, "")
        If Tag = "0" Then
            '展开添加面板
            PanAddSource.Visibility = Visibility.Visible
            TextSourceName.Text = ""
            TextSourceUrl.Text = ""
            ComboSourceProtocol.SelectedIndex = 0
            Return
        End If
        LastSourceIndex = ComboSearchSource.SelectedIndex
        PanAddSource.Visibility = Visibility.Collapsed
        ApplyCustomSource()
    End Sub

    Private Sub BtnSourceSave_Click(sender As Object, e As MouseButtonEventArgs) Handles BtnSourceSave.Click
        Dim SourceName As String = TextSourceName.Text.Trim()
        Dim SourceUrl As String = TextSourceUrl.Text.Trim()
        If SourceName.Length = 0 Then
            Hint("请先填写源名称", HintType.Red)
            Return
        End If
        If Not SourceUrl.StartsWithF("http") Then
            Hint("地址需要以 http:// 或 https:// 开头", HintType.Red)
            Return
        End If
        SourceName = SourceName.Replace(CustomSourceSuffix, "").Trim()
        Dim Protocol As String = "2"
        Dim SelectedProtocol As MyComboBoxItem = TryCast(ComboSourceProtocol.SelectedItem, MyComboBoxItem)
        If SelectedProtocol IsNot Nothing AndAlso SelectedProtocol.Tag IsNot Nothing Then Protocol = SelectedProtocol.Tag.ToString
        Try
            Dim Arr As JArray = ReadCustomSources()
            Dim Exists As Boolean = False
            For Each Token As JToken In Arr
                Dim Source As JObject = CType(Token, JObject)
                If Source("name").ToString <> SourceName Then Continue For
                Source("url") = SourceUrl
                Source("protocol") = Protocol
                Exists = True
                Exit For
            Next
            If Not Exists Then
                Dim NewSource As New JObject
                NewSource("name") = SourceName
                NewSource("url") = SourceUrl
                NewSource("protocol") = Protocol
                Arr.Add(NewSource)
            End If
            Settings.Set("CustomModSources", Arr.ToString(Newtonsoft.Json.Formatting.None))
            PanAddSource.Visibility = Visibility.Collapsed
            RefreshSourceCombo()
            For Each Item As MyComboBoxItem In ComboSearchSource.Items
                If Item.Content IsNot Nothing AndAlso Item.Content.ToString = SourceName & CustomSourceSuffix Then
                    ComboSearchSource.SelectedItem = Item
                    Exit For
                End If
            Next
            Hint($"已保存自定义源：{SourceName}", HintType.Green)
        Catch ex As Exception
            Logger.Error(ex, "保存自定义源失败")
            Hint("保存自定义源失败：" & ex.Message, HintType.Red)
        End Try
    End Sub

    Private Sub BtnSourceCancel_Click(sender As Object, e As MouseButtonEventArgs) Handles BtnSourceCancel.Click
        PanAddSource.Visibility = Visibility.Collapsed
        ComboSearchSource.SelectedIndex = Math.Max(0, LastSourceIndex)
    End Sub

#End Region

    '安装已有整合包按钮
    Private Sub BtnSearchInstallModPack_Click(sender As Object, e As EventArgs) Handles BtnSearchInstallModPack.Click
        ModpackInstall()
    End Sub

End Class
