﻿Public Class MyImage
    Inherits Image

#Region "公开属性"

    ''' <summary>
    ''' 网络图片的缓存有效期。
    ''' 在这个时间后，才会重新尝试下载图片。
    ''' </summary>
    Public FileCacheExpiredTime As New TimeSpan(7, 0, 0, 0) '7 天

    ''' <summary>
    ''' 是否允许将网络图片存储到本地用作缓存。
    ''' </summary>
    Public Property EnableCache As Boolean
        Get
            Return GetValue(EnableCacheProperty)
        End Get
        Set(value As Boolean)
            SetValue(EnableCacheProperty, value)
        End Set
    End Property
    Public Shared Shadows ReadOnly EnableCacheProperty As DependencyProperty = DependencyProperty.Register(
        "EnableCache", GetType(Boolean), GetType(MyImage), New PropertyMetadata(True))

    ''' <summary>
    ''' 与 Image 的 Source 类似。
    ''' 若输入以 http 开头的字符串，则会尝试下载图片然后显示；若 EnableCache 设为 True，图片还会保存为本地缓存。
    ''' 支持 WebP 格式的图片。
    ''' </summary>
    Public Shadows Property Source As String '覆写 Image 的 Source 属性
        Get
            Return _Source
        End Get
        Set(value As String)
            If value = "" Then value = Nothing
            If _Source = value Then Return
            _Source = value
            If Not IsInitialized Then Return '属性读取顺序修正：在完成 XAML 属性读取后再触发图片加载（#4868）
            Load()
        End Set
    End Property
    Private _Source As String = ""
    Public Shared Shadows ReadOnly SourceProperty As DependencyProperty = DependencyProperty.Register(
        "Source", GetType(String), GetType(MyImage), New PropertyMetadata(New PropertyChangedCallback(
    Sub(sender, e) If sender IsNot Nothing Then CType(sender, MyImage).Source = e.NewValue.ToString())))

    ''' <summary>
    ''' 若 Source 是一个网络图片，该地址将作为第二图片源。
    ''' </summary>
    Public Property FallbackSource As String
        Get
            Return _FallbackSource
        End Get
        Set(value As String)
            _FallbackSource = value
        End Set
    End Property
    Private _FallbackSource As String = Nothing

    ''' <summary>
    ''' 正在下载网络图片时显示的本地图片。
    ''' </summary>
    Public Property LoadingSource As String
        Get
            Return _LoadingSource
        End Get
        Set(value As String)
            _LoadingSource = value
        End Set
    End Property
    Private _LoadingSource As String = "pack://application:,,,/images/Icons/NoIcon.png"

#End Region

    ''' <summary>
    ''' 实际被呈现的图片地址。
    ''' </summary>
    Public Property ActualSource As String
        Get
            Return _ActualSource
        End Get
        Set(value As String)
            If value = "" Then value = Nothing
            If _ActualSource = value Then Return
            _ActualSource = value
            Try
                Dim Bitmap As ImageSource = If(value Is Nothing, Nothing, New MyBitmap(value)) '在这里先触发可能的文件读取，尽量避免在 UI 线程中读取文件
                RunInUi(Sub() MyBase.Source = Bitmap)
            Catch ex As Exception
                Logger.Warn(ex, $"加载图片失败（{value}）")
                Try
                    If value.StartsWithF(PathTemp, True) Then FileUtils.Delete(value)
                Catch
                End Try
            End Try
        End Set
    End Property
    Private _ActualSource As String = Nothing

    Private Sub Load() _
        Handles Me.Initialized '属性读取顺序修正：在完成 XAML 属性读取后再触发图片加载（#4868）
        '空
        If Source Is Nothing Then
            ActualSource = Nothing
            Return
        End If
        '本地图片
        If Not Source.StartsWithF("http") Then
            ActualSource = Source
            Return
        End If
        '从缓存加载网络图片
        Dim EnableCache As Boolean = Me.EnableCache
        Dim TempPath As String = $"{PathTemp}MyImage\{Source.GetStableHashCode()}.png{If(EnableCache, "", GetUuid())}" '不启用缓存时在末尾加上随机字符串，避免冲突
        Dim TempFile = FileUtils.GetInfo(TempPath)
        Dim HasValidCache As Boolean = EnableCache AndAlso TempFile.Exists AndAlso TempFile.Length > 0
        If HasValidCache Then
            ActualSource = TempPath '显示缓存的图片
            If (Date.Now - TempFile.LastWriteTime) < FileCacheExpiredTime Then Return '无需刷新缓存
        Else
            ActualSource = LoadingSource '显示加载中图片
        End If
        '失败抑制：同一张图 30 分钟内下载失败过就不再重复请求，避免列表滚动时疯狂重试拖慢界面
        Dim FailMark As String = TempPath & ".fail"
        Dim FailInfo = FileUtils.GetInfo(FailMark)
        If EnableCache AndAlso FailInfo.Exists AndAlso (Date.Now - FailInfo.LastWriteTime) < New TimeSpan(0, 30, 0) Then Return
        RunInNewThread(
        Sub()
            Dim NewPath As String = TempPath & ".new"
            Dim IsLocalFallback As Boolean = Not String.IsNullOrEmpty(FallbackSource) AndAlso Not FallbackSource.StartsWithF("http")
            Try
                '先下载到临时新文件，成功后再替换，失败时不会把已有缓存图一起删掉（原来失败即删缓存，导致图片变空白）
                NetDownloadByLoader(
                    If(FallbackSource IsNot Nothing AndAlso FallbackSource.StartsWithF("http") AndAlso Source <> FallbackSource,
                        {Source, FallbackSource}, {Source}),
                    NewPath, SimulateBrowserHeaders:=True)
                If EnableCache Then
                    Try
                        FileUtils.Delete(TempPath)
                        FileUtils.Move(NewPath, TempPath)
                        ActualSource = TempPath
                    Catch
                        ActualSource = NewPath '替换缓存失败就直接显示新文件，避免图片变空白
                    End Try
                    Try
                        FileUtils.Delete(FailMark)
                    Catch
                    End Try
                Else
                    ActualSource = NewPath '不启用缓存时保留文件供显示，不能下载完就删
                End If
            Catch ex As Exception
                Try
                    FileUtils.Delete(NewPath)
                Catch
                End Try
                Try
                    If EnableCache Then FileUtils.Write(FailMark, "") '记录失败时间，短期不再重试
                Catch
                End Try
                '加载本地备用图片
                If IsLocalFallback Then
                    Try
                        ActualSource = FallbackSource
                        Logger.Warn(ex, $"下载图片失败，使用本地备用图片（{Source}）")
                        Return
                    Catch exx As Exception
                        Logger.Warn(ex, $"下载图片失败（{Source}）")
                        Logger.Warn(exx, $"加载备用图片失败（{FallbackSource}）")
                    End Try
                Else
                    '图片只是装饰，失败时静默记日志，不再弹 Toast 刷屏（原来每张失败图都会弹一次提示）
                    Logger.Warn(ex, $"下载图片失败（{Source}，备用：{FallbackSource}）")
                End If
            End Try
        End Sub, "MyImage PicLoader " & GetUuid() & "#", ThreadPriority.BelowNormal)
    End Sub

End Class